import{W as n}from"./index-CQgN-4QV.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
