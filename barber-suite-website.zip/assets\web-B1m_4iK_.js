import{W as n}from"./index-DAA_DnuW.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
